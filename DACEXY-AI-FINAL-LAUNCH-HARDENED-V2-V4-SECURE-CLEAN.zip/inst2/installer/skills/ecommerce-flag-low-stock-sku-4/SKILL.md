---
name: ecommerce-flag-low-stock-sku-4
description: Business automation skill - flag low stock SKU 4 (ecommerce). Use when the user asks to flag low stock SKU 4 or a close equivalent in the ecommerce domain.
---

# Flag Low Stock Sku 4

## Goal
Help the user flag low stock SKU 4 accurately and efficiently as part of Dacexy business automation (ecommerce category).

## Steps
1. Confirm the specific record/entity involved (customer, invoice, deal, ticket, employee, product, etc.) before acting.
2. Gather any required data from connected tools (CRM, spreadsheet, email, files) rather than guessing values.
3. Perform the action precisely as requested; do not fabricate data, amounts, or dates.
4. Confirm the result back to the user in plain language (what changed, where, and any follow-up needed).
5. If the action is destructive or financial (delete, refund, send payment, terminate), ask for explicit confirmation first.

## Notes
- Never invent customer data, financial figures, or dates that were not provided or retrieved from a real source.
- Prefer existing connected tools/integrations over manual free-text guesses.
