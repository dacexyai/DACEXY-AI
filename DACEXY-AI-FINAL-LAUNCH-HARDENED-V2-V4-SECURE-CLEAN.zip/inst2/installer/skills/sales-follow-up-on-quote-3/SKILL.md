---
name: sales-follow-up-on-quote-3
description: Business automation skill - follow up on quote 3 (sales). Use when the user asks to follow up on quote 3 or a close equivalent in the sales domain.
---

# Follow Up On Quote 3

## Goal
Help the user follow up on quote 3 accurately and efficiently as part of Dacexy business automation (sales category).

## Steps
1. Confirm the specific record/entity involved (customer, invoice, deal, ticket, employee, product, etc.) before acting.
2. Gather any required data from connected tools (CRM, spreadsheet, email, files) rather than guessing values.
3. Perform the action precisely as requested; do not fabricate data, amounts, or dates.
4. Confirm the result back to the user in plain language (what changed, where, and any follow-up needed).
5. If the action is destructive or financial (delete, refund, send payment, terminate), ask for explicit confirmation first.

## Notes
- Never invent customer data, financial figures, or dates that were not provided or retrieved from a real source.
- Prefer existing connected tools/integrations over manual free-text guesses.
